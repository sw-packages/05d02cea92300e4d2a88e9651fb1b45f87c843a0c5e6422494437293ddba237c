#include "tgbot/EventHandler.h"

#include <algorithm>
#include <cstddef>
#include <string_view>

namespace TgBot {

EventHandler::EventHandler(const EventBroadcaster& broadcaster)
    : _broadcaster(broadcaster) {
}

void EventHandler::handleUpdate(const std::shared_ptr<Update>& update) const {
    if (update->message != nullptr) {
        handleMessage(update->message);
    }
    if (update->editedMessage != nullptr) {
        _broadcaster.broadcastEditedMessage(update->editedMessage);
    }
    if (update->channelPost != nullptr) {
        handleMessage(update->channelPost);
    }
    if (update->editedChannelPost != nullptr) {
        _broadcaster.broadcastEditedMessage(update->editedChannelPost);
    }
    if (update->inlineQuery != nullptr) {
        _broadcaster.broadcastInlineQuery(update->inlineQuery);
    }
    if (update->chosenInlineResult != nullptr) {
        _broadcaster.broadcastChosenInlineResult(update->chosenInlineResult);
    }
    if (update->callbackQuery != nullptr) {
        _broadcaster.broadcastCallbackQuery(update->callbackQuery);
    }
    if (update->shippingQuery != nullptr) {
        _broadcaster.broadcastShippingQuery(update->shippingQuery);
    }
    if (update->preCheckoutQuery != nullptr) {
        _broadcaster.broadcastPreCheckoutQuery(update->preCheckoutQuery);
    }
    if (update->poll != nullptr) {
        _broadcaster.broadcastPoll(update->poll);
    }
    if (update->pollAnswer != nullptr) {
        _broadcaster.broadcastPollAnswer(update->pollAnswer);
    }
    if (update->myChatMember != nullptr) {
        _broadcaster.broadcastMyChatMember(update->myChatMember);
    }
    if (update->chatMember != nullptr) {
        _broadcaster.broadcastChatMember(update->chatMember);
    }
    if (update->chatJoinRequest != nullptr) {
        _broadcaster.broadcastChatJoinRequest(update->chatJoinRequest);
    }
    if (update->messageReaction != nullptr) {
        _broadcaster.broadcastMessageReactionUpdated(update->messageReaction);
    }
    if (update->messageReactionCount != nullptr) {
        _broadcaster.broadcastMessageReactionCountUpdated(update->messageReactionCount);
    }
    if (update->stoppedMessageGeneration != nullptr) {
        _broadcaster.broadcastMessageGenerationStopped(update->stoppedMessageGeneration);
    }
}

void EventHandler::handleMessage(const std::shared_ptr<Message>& message) const {
    _broadcaster.broadcastAnyMessage(message);

    const std::string_view text = message->text ? std::string_view(*message->text) : "";
    if (text.starts_with('/')) {
        std::size_t splitPosition;
        std::size_t spacePosition = text.find(' ');
        std::size_t atSymbolPosition = text.find('@');
        if (spacePosition == std::string_view::npos) {
            if (atSymbolPosition == std::string_view::npos) {
                splitPosition = text.size();
            } else {
                splitPosition = atSymbolPosition;
            }
        } else if (atSymbolPosition == std::string_view::npos) {
            splitPosition = spacePosition;
        } else {
            splitPosition = std::min(spacePosition, atSymbolPosition);
        }
        const std::string_view command = text.substr(1, splitPosition - 1);
        if (!_broadcaster.broadcastCommand(command, message)) {
            _broadcaster.broadcastUnknownCommand(message);
        }
    } else {
        _broadcaster.broadcastNonCommandMessage(message);
    }

    if (message->successfulPayment != nullptr) {
        _broadcaster.broadcastSuccessfulPayment(message);
    }
}

} // namespace TgBot
